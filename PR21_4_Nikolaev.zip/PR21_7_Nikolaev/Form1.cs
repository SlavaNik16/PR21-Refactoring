﻿using System;
using System.Windows.Forms;

namespace PR21_7_Nikolaev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = Properties.Settings.Default.ToString();
            connectionString = NewMethod(connectionString);
            MessageBox.Show(connectionString);
        }

        private static string NewMethod(string connectionString)
        {
            if (connectionString == null)
            {
                connectionString = "Строка соединения по умолчанию";
            }

            return connectionString;
        }
    }
}
