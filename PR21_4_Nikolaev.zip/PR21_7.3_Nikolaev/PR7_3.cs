﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR21_7._3_Nikolaev
{
    class PR7_3 : IPR7_3
    {
        public void ShouldBeInInterface() { }
        public void AnotherNormalMethod(int ParametrA, int ParametrB) { }
        private void NormalMethod() { }

        static void Main(string[] args)
        {
        }
    }
}
