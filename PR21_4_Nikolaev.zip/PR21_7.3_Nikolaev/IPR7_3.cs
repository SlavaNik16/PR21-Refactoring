﻿namespace PR21_7._3_Nikolaev
{
    internal interface IPR7_3
    {
        void ShouldBeInInterface();
    }
}