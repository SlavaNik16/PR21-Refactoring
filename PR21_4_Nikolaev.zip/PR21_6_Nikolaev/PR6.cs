﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR21_6_Nikolaev
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
