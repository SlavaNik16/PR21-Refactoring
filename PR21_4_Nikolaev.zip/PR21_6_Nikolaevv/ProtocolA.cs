﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR21_6_Nikolaevv
{
    class ProtocolA
    {
        public void MethodB(bool b, int i) { }
    }
    class ProtocolC
    {
        void D()
        {
            var myClass = new ProtocolA();
            myClass.MethodB(false, 0);
        }
    }
}
