﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR21_5_Nikolaev
{
    class PR5
    {
        class A
        {
            public A(string s) { }
        }
        class B
        {
            void C()
            {
                A a = new A("a");
            }
        }
        static void Main(string[] args)
        {

        }
    }
}
