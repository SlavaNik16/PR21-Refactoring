﻿namespace PR21_4_Nikolaev
{
    internal interface IProtoA
    {
        void MethodB(string s);
    }
}