﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR21_4_Nikolaev
{
     class PR4
    {
        static void Main(string[] args)
        {
        }


        class ProtoA : IProtoA
        {
            public void MethodB(string s) { }
        }
    }
}
