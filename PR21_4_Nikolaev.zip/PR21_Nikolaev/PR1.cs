﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR21_Nikolaev
{
     class PR1
    {
        delegate void D();
        D d;
        static void Main(string[] args)
        {
            var a = new A();
            Console.WriteLine($"{a.CalculatePaintHeaded(3, 10)}");

            Paint();

            var pr1 = new PR1();
            int i = 10;
            i = NewMethod(pr1, i);
            i++;
            pr1.d();
            Console.ReadLine();

        }
        private static void Paint()
        {
            Console.Title = "Мое приложение";
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("Привет, это мой проект!");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        private static int NewMethod(PR1 pr1, int i)
        {
            pr1.d = delegate { Console.WriteLine(i++); };
            return i;
        }
        class A
        {
            const double PI = 3.141592;

            public double CalculatePaintHeaded(double paintPerUnit, double radius)
            {
                double area = Area(radius);
                return area / paintPerUnit;
            }

            private static double Area(double radius)
            {
                return PI * Math.Pow(radius, 2);
            }
        }
    }
}
